package z2;

import java.util.List;

interface ImienneZwierze {
    String getImie();
    String dajGlos();
}

abstract class Zwierze {
    private int wiek;

    public Zwierze(int wiek) {
        this.wiek = wiek;
    }

    public int getWiek() {
        return wiek;
    }

    public abstract int getIleNog();
}

class Pies extends Zwierze implements ImienneZwierze {
    private String imie;

    public Pies(int wiek, String imie) {
        super(wiek);
        this.imie = imie;
    }

    @Override
    public String getImie() {
        return imie;
    }

    @Override
    public String dajGlos() {
        return "Hau hau";
    }

    @Override
    public int getIleNog() {
        return 4;
    }
}

class Ryba extends Zwierze implements ImienneZwierze {
    public Ryba(int wiek) {
        super(wiek);
    }

    @Override
    public String getImie() {
        return "Ryba bez imienia";
    }

    @Override
    public String dajGlos() {
        return "Bul bul";
    }

    @Override
    public int getIleNog() {
        return 0;
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("0");
        List<Zwierze> zwierzeta = List.of(new Pies(10, "Burek"), new Ryba(1));
        Pies pies = (Pies) zwierzeta.get(0);
        Ryba ryba = (Ryba) zwierzeta.get(1);

        assert pies.getIleNog() == 4;
        assert pies.getWiek() == 10;
        assert pies.getImie().equals("Burek");
        assert ryba.getIleNog() == 0;
        assert ryba.getWiek() == 1;
        assert pies.dajGlos().equals("Hau hau");
        assert ryba.dajGlos().equals("Bul bul");
        assert ImienneZwierze.class.isInstance(pies);
        assert !ImienneZwierze.class.isInstance(ryba);
    }
}
