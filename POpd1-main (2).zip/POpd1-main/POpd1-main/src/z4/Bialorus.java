package z4;

public class Bialorus extends PanstwoEuropejskie {
    public Bialorus() {
        super(9400000, "Mińsk");
    }
}
