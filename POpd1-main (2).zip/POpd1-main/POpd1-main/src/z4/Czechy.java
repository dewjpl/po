package z4;

public class Czechy extends PanstwoEuropejskie {
    public Czechy() {
        super(10610000, "Praga");
    }
}
