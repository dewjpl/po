package z4;

public class PanstwoEuropejskie extends Panstwo {

    public PanstwoEuropejskie(int liczbaLudnosci, String stolica) {
        super(Kontynent.EUROPA, liczbaLudnosci, stolica);
    }
}
