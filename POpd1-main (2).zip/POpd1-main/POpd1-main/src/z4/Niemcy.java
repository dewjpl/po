package z4;

public class Niemcy extends PanstwoEuropejskie {
    public Niemcy() {
        super(83000000, "Berlin");
    }
}
