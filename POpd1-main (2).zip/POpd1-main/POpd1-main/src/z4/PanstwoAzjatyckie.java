package z4;

public class PanstwoAzjatyckie extends Panstwo {

    public PanstwoAzjatyckie(int liczbaLudnosci, String stolica) {
        super(Kontynent.AZJA, liczbaLudnosci, stolica);
    }
}
