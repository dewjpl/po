package z4;

public enum Kontynent {
    EUROPA, AZJA
}
