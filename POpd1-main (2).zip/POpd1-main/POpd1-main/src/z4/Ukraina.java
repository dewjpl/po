package z4;

public class Ukraina extends PanstwoEuropejskie {
    public Ukraina() {
        super(44000000, "Kijów");
    }
}
