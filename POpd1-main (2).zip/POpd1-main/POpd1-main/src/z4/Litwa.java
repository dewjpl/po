package z4;

public class Litwa extends PanstwoEuropejskie {
    public Litwa() {
        super(2794000, "Wilno");
    }
}
