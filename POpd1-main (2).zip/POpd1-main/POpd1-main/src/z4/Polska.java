package z4;

public class Polska extends PanstwoEuropejskie {
    public Polska() {
        super(37750000, "Warszawa");
    }
}
