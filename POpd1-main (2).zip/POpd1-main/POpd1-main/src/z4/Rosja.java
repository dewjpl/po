package z4;

public class Rosja extends PanstwoAzjatyckie {
    public Rosja() {
        super(144000000, "Moskwa");
    }

    public void migruj(PanstwoEuropejskie panstwo, int liczbaEmigrantow) {
        int aktualnaLiczbaLudnosci = this.getLiczbaLudnosci();
        aktualnaLiczbaLudnosci -= liczbaEmigrantow;
        this.setLiczbaLudnosci(aktualnaLiczbaLudnosci);

        int liczbaLudnosciPanstwa = panstwo.getLiczbaLudnosci();
        liczbaLudnosciPanstwa += liczbaEmigrantow;
        panstwo.setLiczbaLudnosci(liczbaLudnosciPanstwa);
    }
}
