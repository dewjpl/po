package z4;

public class Slowacja extends PanstwoEuropejskie {
    public Slowacja() {
        super(5450000, "Bratysława");
    }
}
