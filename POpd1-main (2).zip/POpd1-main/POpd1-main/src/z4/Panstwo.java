package z4;

import java.util.ArrayList;
import java.util.List;

public class Panstwo {
    private Kontynent kontynent;
    private int liczbaLudnosci;
    private String stolica;
    private List<Panstwo> sasiedzi;

    public Panstwo(Kontynent kontynent, int liczbaLudnosci, String stolica) {
        this.kontynent = kontynent;
        this.liczbaLudnosci = liczbaLudnosci;
        this.stolica = stolica;
        this.sasiedzi = new ArrayList<>();
    }

    public Kontynent getKontynent() {
        return kontynent;
    }

    public int getLiczbaLudnosci() {
        return liczbaLudnosci;
    }

    public String getStolica() {
        return stolica;
    }

    public List<Panstwo> getSasiedzi() {
        return sasiedzi;
    }

    public void setLiczbaLudnosci(int liczbaLudnosci) {
        this.liczbaLudnosci = liczbaLudnosci;
    }

    public void dodajSasiada(Panstwo panstwo) {
        sasiedzi.add(panstwo);
        panstwo.getSasiedzi().add(this);
    }
}
