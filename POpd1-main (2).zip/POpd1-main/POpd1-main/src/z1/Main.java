package z1;

import java.util.Objects;

class Pracownik {
    private Pracownik przelozony;
    private int pensja;

    public Pracownik(int pensja) {
        this.pensja = pensja;
    }

    public Pracownik(Pracownik przelozony, int dodatek) {
        this.przelozony = przelozony;
        this.pensja = przelozony.getPensja() + dodatek;
    }

    public int getPensja() {
        return pensja;
    }

    public Pracownik getPrzelozony() {
        return przelozony;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pracownik pracownik = (Pracownik) o;
        return pensja == pracownik.pensja &&
                Objects.equals(przelozony, pracownik.przelozony);
    }

    @Override
    public int hashCode() {
        return Objects.hash(przelozony, pensja);
    }

    public static void main(String[] args) {
        Dyrektor dyrektor = new Dyrektor(100000);
        Kierownik kierownik = new Kierownik(dyrektor, 20000);
        Menadzer menadzer = new Menadzer(kierownik, 10000);
        Pracownik pracownik = new Pracownik(menadzer, 5000);
        Stazysta stazysta = new Stazysta(menadzer);

        assert stazysta.getPensja() == 3600;
        assert pracownik.getPensja() == 5000;
        assert menadzer.getPensja() == 10000;
        assert kierownik.getPensja() == 20000;
        assert dyrektor.getPensja() == 100000;
        assert Objects.equals(stazysta.getPrzelozony(), pracownik.getPrzelozony());
        assert Objects.equals(stazysta.getPrzelozony().getPrzelozony().getPrzelozony(), dyrektor);
        assert Objects.equals(null, dyrektor.getPrzelozony());

        System.out.println("Wartość 0");
    }
}

class Dyrektor extends Pracownik {
    public Dyrektor(int pensja) {
        super(pensja);
    }
}

class Kierownik extends Pracownik {
    public Kierownik(Pracownik przelozony, int dodatek) {
        super(przelozony, dodatek);
    }
}

class Menadzer extends Pracownik {
    public Menadzer(Pracownik przelozony, int dodatek) {
        super(przelozony, dodatek);
    }
}

class Stazysta extends Pracownik {
    public Stazysta(Pracownik przelozony) {
        super((int) (przelozony.getPensja() * 0.6));
    }
}